import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { deriveRun, resolveRun, type Derived } from './engine'
import { TOUR, type BreakId, type CameraKey, type Mode, type NodeId, type RunRef, type ScenarioId } from './scenes'

export type RunStatus = 'idle' | 'running' | 'done'
const TICK_MS = 80

export function usePrefersReducedMotion() {
  const [reduced, setReduced] = useState(() => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches)
  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)')
    const on = () => setReduced(mq.matches)
    mq.addEventListener('change', on)
    return () => mq.removeEventListener('change', on)
  }, [])
  return reduced
}

export interface Workbench {
  reducedMotion: boolean
  mode: Mode
  ref: RunRef
  runStatus: RunStatus
  elapsedMs: number
  durationMs: number
  derived: Derived
  payload: ReturnType<typeof resolveRun>['payload']
  focus: CameraKey
  /** increments on every focus request so the camera re-flies even to the same target */
  focusTick: number
  selected: NodeId | null
  crateOpen: boolean
  tourStep: number | null
  setMode: (m: Mode) => void
  chooseScenario: (id: ScenarioId) => void
  breakIt: (id: BreakId) => void
  replay: () => void
  focusNode: (id: NodeId) => void
  toggleCrate: () => void
  startTour: () => void
  tourNext: () => void
  tourBack: () => void
  endTour: () => void
}

export function useWorkbench(): Workbench {
  const reducedMotion = usePrefersReducedMotion()
  const [mode, setModeState] = useState<Mode>('guarded')
  const [ref, setRef] = useState<RunRef>({ kind: 'scenario', id: 'delegatecall' })
  const [runStatus, setRunStatus] = useState<RunStatus>('idle')
  const [elapsedMs, setElapsed] = useState(0)
  const [focus, setFocus] = useState<CameraKey>('overview')
  const [focusTick, setFocusTick] = useState(0)
  const [selected, setSelected] = useState<NodeId | null>(null)
  const [crateOpen, setCrateOpen] = useState(false)
  const [tourStep, setTourStep] = useState<number | null>(null)
  const timer = useRef<number | undefined>(undefined)

  const stop = useCallback(() => {
    if (timer.current !== undefined) window.clearInterval(timer.current)
    timer.current = undefined
  }, [])

  const play = useCallback(
    (nextRef: RunRef, nextMode: Mode) => {
      stop()
      setRef(nextRef)
      setModeState(nextMode)
      setElapsed(0)
      setRunStatus('running')
      const duration = resolveRun(nextRef, nextMode).durationMs
      const t0 = performance.now()
      timer.current = window.setInterval(() => {
        const el = performance.now() - t0
        if (el >= duration) {
          stop()
          setElapsed(duration)
          setRunStatus('done')
        } else setElapsed(el)
      }, TICK_MS)
    },
    [stop],
  )

  useEffect(() => stop, [stop])

  const setMode = useCallback(
    (m: Mode) => {
      // a break-it run only makes sense with the guard on; toggling off returns to the attack scenario
      const nextRef: RunRef = ref.kind === 'break' && m === 'unguarded' ? { kind: 'scenario', id: 'delegatecall' } : ref
      play(nextRef, m)
    },
    [play, ref],
  )
  const chooseScenario = useCallback((id: ScenarioId) => play({ kind: 'scenario', id }, mode), [play, mode])
  const breakIt = useCallback((id: BreakId) => play({ kind: 'break', id }, 'guarded'), [play])
  const replay = useCallback(() => play(ref, mode), [play, ref, mode])

  const focusNode = useCallback((id: NodeId) => {
    // the vault opens its storage-slot grid, so it gets a closer pose than the tour's vault shot
    setFocus(id === 'vault' ? 'vaultSlots' : id)
    setFocusTick((n) => n + 1)
    setSelected(id)
  }, [])
  const toggleCrate = useCallback(() => setCrateOpen((o) => !o), [])

  const applyStep = useCallback(
    (i: number) => {
      const step = TOUR[i]
      setTourStep(i)
      setFocus(step.camera)
      setFocusTick((n) => n + 1)
      setSelected(step.select ?? null)
      const a = step.action
      if (a?.crateOpen !== undefined) setCrateOpen(a.crateOpen)
      if (a?.run) play({ kind: 'scenario', id: a.scenario ?? 'delegatecall' }, a.mode ?? mode)
    },
    [play, mode],
  )
  const startTour = useCallback(() => applyStep(0), [applyStep])
  const endTour = useCallback(() => {
    setTourStep(null)
    setFocus('overview')
    setFocusTick((n) => n + 1)
    setSelected(null)
  }, [])
  const tourNext = useCallback(() => {
    if (tourStep === null) return
    if (tourStep >= TOUR.length - 1) endTour()
    else applyStep(tourStep + 1)
  }, [tourStep, applyStep, endTour])
  const tourBack = useCallback(() => {
    if (tourStep !== null && tourStep > 0) applyStep(tourStep - 1)
  }, [tourStep, applyStep])

  const resolved = useMemo(() => resolveRun(ref, mode), [ref, mode])
  const derived = useMemo(() => deriveRun(ref, mode, runStatus === 'idle' ? -1 : elapsedMs), [ref, mode, runStatus, elapsedMs])

  return {
    reducedMotion,
    mode,
    ref,
    runStatus,
    elapsedMs,
    durationMs: resolved.durationMs,
    derived,
    payload: resolved.payload,
    focus,
    focusTick,
    selected,
    crateOpen,
    tourStep,
    setMode,
    chooseScenario,
    breakIt,
    replay,
    focusNode,
    toggleCrate,
    startTour,
    tourNext,
    tourBack,
    endTour,
  }
}
