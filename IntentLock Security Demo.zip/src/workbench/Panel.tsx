import { useRef, type KeyboardEvent } from 'react'
import { ArrowRight, ChevronLeft, Play, RotateCcw, ShieldCheck, ShieldOff, X } from 'lucide-react'
import { outcomeOf } from './engine'
import { BREAKS, INFO_HINT, NODE_INFO, SCENARIOS, STAMP_TEXT, TOUR, type BreakId, type NodeId, type ScenarioId } from './scenes'
import type { Workbench } from './useWorkbench'

const NODE_ORDER: NodeId[] = ['proposal', 'payload', 'verifierA', 'verifierB', 'verifierC', 'registry', 'gate', 'vault']

const eyebrow = 'font-mono text-[11px] font-bold uppercase tracking-[0.16em] text-[#a89f90]'
const chip = 'rounded border px-2 py-0.5 font-mono text-[11px] font-bold tracking-wider'

export function Panel({ wb }: { wb: Workbench }) {
  const tabs = useRef<Record<string, HTMLButtonElement | null>>({})
  const guarded = wb.mode === 'guarded'
  const running = wb.runStatus === 'running'
  const pct = wb.runStatus === 'idle' ? 0 : Math.min(100, (wb.elapsedMs / wb.durationMs) * 100)
  const activeScenario = wb.ref.kind === 'scenario' ? wb.ref.id : null
  const d = wb.derived

  function onTabKey(e: KeyboardEvent, i: number) {
    const last = SCENARIOS.length - 1
    const next = e.key === 'ArrowRight' ? (i === last ? 0 : i + 1) : e.key === 'ArrowLeft' ? (i === 0 ? last : i - 1) : null
    if (next === null) return
    e.preventDefault()
    const id = SCENARIOS[next].id
    wb.chooseScenario(id)
    tabs.current[id]?.focus()
  }

  const info = wb.selected ? NODE_INFO[wb.selected] : null

  return (
    <div className="flex flex-col gap-7 p-5 pb-10 text-[#F5EEDF] lg:p-6">
      <header>
        <p className={eyebrow}>Deep dive</p>
        <h1 className="mt-1 font-display text-3xl font-extrabold uppercase leading-none tracking-tight">Intent workbench</h1>
        <p className="mt-2 text-sm text-[#a89f90]">Same payload, two wallets. Flip the guard and watch what changes.</p>
      </header>

      {/* 1. guard toggle */}
      <section aria-labelledby="wb-guard">
        <h2 id="wb-guard" className={eyebrow}>1 · Guard</h2>
        <div role="radiogroup" aria-label="Guard mode" className="mt-2 grid grid-cols-2 gap-1 rounded-full border border-[#3a332b] bg-[#14110e] p-1">
          {([['unguarded', 'Unguarded', ShieldOff], ['guarded', 'Guarded', ShieldCheck]] as const).map(([m, label, Icon]) => (
            <button
              key={m}
              type="button"
              role="radio"
              aria-checked={wb.mode === m}
              onClick={() => wb.setMode(m)}
              className={`flex items-center justify-center gap-2 rounded-full px-4 py-2.5 text-sm font-bold transition-colors ${
                wb.mode === m ? 'bg-[#FF5B14] text-[#120f0c]' : 'text-[#c9c0b0] hover:text-[#F5EEDF]'
              }`}
            >
              <Icon className="size-4" aria-hidden />
              {label}
            </button>
          ))}
        </div>
        <p className="mt-2 text-sm text-[#a89f90]">{guarded ? 'Verifiers and the gate check every payload.' : 'No checks. Quorum alone moves funds.'}</p>
      </section>

      {/* 2. scenarios */}
      <section aria-labelledby="wb-scn">
        <h2 id="wb-scn" className={eyebrow}>2 · Scenario</h2>
        <div role="tablist" aria-label="Scenario" className="mt-2 grid gap-2">
          {SCENARIOS.map((s, i) => {
            const sel = activeScenario === s.id
            return (
              <button
                key={s.id}
                ref={(el) => {
                  tabs.current[s.id] = el
                }}
                role="tab"
                aria-selected={sel}
                tabIndex={sel || (!activeScenario && i === 0) ? 0 : -1}
                onClick={() => wb.chooseScenario(s.id as ScenarioId)}
                onKeyDown={(e) => onTabKey(e, i)}
                className={`rounded-xl border px-4 py-3 text-left transition-colors ${
                  sel ? 'border-[#FF5B14] bg-[#FF5B14]/12' : 'border-[#2f2922] bg-[#14110e] hover:border-[#5a4d3f]'
                }`}
              >
                <span className="block font-display text-base font-extrabold uppercase tracking-tight">{s.label}</span>
                <span className="block text-sm text-[#a89f90]">{s.blurb}</span>
              </button>
            )
          })}
        </div>
        <div className="mt-3 flex items-center gap-3">
          <button type="button" onClick={wb.replay} className="inline-flex items-center gap-2 rounded-full bg-[#FF5B14] px-5 py-2.5 text-sm font-bold text-[#120f0c] transition-colors hover:bg-[#ff7a3a]">
            {running || wb.runStatus === 'done' ? <RotateCcw className="size-4" aria-hidden /> : <Play className="size-4" aria-hidden fill="currentColor" />}
            {running || wb.runStatus === 'done' ? 'Replay' : 'Play'}
          </button>
          <div role="progressbar" aria-label="Run progress" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(pct)} className="h-1.5 flex-1 overflow-hidden rounded-full bg-[#2a241d]">
            <div className="h-full bg-[#FF5B14] transition-[width] duration-100 ease-linear" style={{ width: `${pct}%` }} />
          </div>
        </div>
      </section>

      {/* outcome */}
      <section aria-live="polite" aria-label="Outcome" className="min-h-[3.5rem]">
        {d.stamp ? (
          <div className={`rounded-xl border px-4 py-3 ${d.stamp === 'ok' ? 'border-[#7ACB8A] bg-[#7ACB8A]/10' : 'border-[#FF3B30] bg-[#FF3B30]/10'}`}>
            <p className={`font-display text-2xl font-extrabold uppercase leading-none ${d.stamp === 'ok' ? 'text-[#7ACB8A]' : 'text-[#ff6a5e]'}`}>{STAMP_TEXT[d.stamp].title}</p>
            <p className="mt-1 text-sm text-[#d8cfbf]">{STAMP_TEXT[d.stamp].sub}</p>
            {d.result?.revert && (
              <p className="mt-2 flex flex-wrap items-center gap-2">
                <span className={`${chip} border-[#ff6a5e] text-[#ff6a5e]`}>{d.result.revert}</span>
                {d.result.fixtureId && <span className={`${chip} border-[#E3A73B] uppercase text-[#E3A73B]`}>{d.result.fixtureId}</span>}
              </p>
            )}
          </div>
        ) : (
          <p className="rounded-xl border border-dashed border-[#3a332b] px-4 py-3 text-sm text-[#a89f90]">No result yet. Press play.</p>
        )}
      </section>

      {/* 3. break it */}
      <section aria-labelledby="wb-break">
        <h2 id="wb-break" className={eyebrow}>3 · Break it</h2>
        <p className="mt-1 text-sm text-[#a89f90]">Each tweak runs with the guard on and names the revert.</p>
        <ul className="mt-2 grid gap-2">
          {BREAKS.map((b) => {
            const o = outcomeOf({ kind: 'break', id: b.id }, 'guarded')
            const sel = wb.ref.kind === 'break' && wb.ref.id === b.id
            return (
              <li key={b.id}>
                <button
                  type="button"
                  onClick={() => wb.breakIt(b.id as BreakId)}
                  aria-pressed={sel}
                  className={`w-full rounded-xl border px-4 py-3 text-left transition-colors ${sel ? 'border-[#FF5B14] bg-[#FF5B14]/12' : 'border-[#2f2922] bg-[#14110e] hover:border-[#5a4d3f]'}`}
                >
                  <span className="block text-[15px] font-bold">{b.label}</span>
                  <span className="mt-1.5 flex flex-wrap items-center gap-2">
                    {o.revert && <span className={`${chip} border-[#ff6a5e] text-[#ff6a5e]`}>{o.revert}</span>}
                    {o.fixtureId && <span className={`${chip} border-[#E3A73B] uppercase text-[#E3A73B]`}>{o.fixtureId}</span>}
                  </span>
                </button>
              </li>
            )
          })}
        </ul>
      </section>

      {/* 4. inspect */}
      <section aria-labelledby="wb-inspect">
        <h2 id="wb-inspect" className={eyebrow}>4 · Inspect</h2>
        <ul className="mt-2 flex flex-wrap gap-1.5">
          {NODE_ORDER.map((n) => (
            <li key={n}>
              <button
                type="button"
                onClick={() => wb.focusNode(n)}
                aria-pressed={wb.selected === n}
                className={`rounded-full border px-3 py-1 text-sm font-medium transition-colors ${wb.selected === n ? 'border-[#FF5B14] bg-[#FF5B14] text-[#120f0c]' : 'border-[#3a332b] text-[#d8cfbf] hover:border-[#8a7a66]'}`}
              >
                {NODE_INFO[n].short}
              </button>
            </li>
          ))}
        </ul>
        <div className="mt-3 rounded-xl border border-[#2f2922] bg-[#14110e] p-4" aria-live="polite">
          {info ? (
            <dl>
              <dt className="font-display text-lg font-extrabold uppercase">{info.title}</dt>
              <dd className="mt-3">
                <span className={eyebrow}>What it is</span>
                <span className="mt-0.5 block text-[15px]">{info.what}</span>
              </dd>
              <dd className="mt-3">
                <span className={eyebrow}>What it checks</span>
                <span className="mt-0.5 block text-[15px]">{info.checks}</span>
              </dd>
              {wb.selected === 'payload' && (
                <dd className="mt-3">
                  <button type="button" onClick={wb.toggleCrate} className="rounded-full border border-[#FF5B14] px-4 py-1.5 text-sm font-bold text-[#FF5B14] hover:bg-[#FF5B14] hover:text-[#120f0c]">
                    {wb.crateOpen ? 'Close the crate' : 'Crack the crate open'}
                  </button>
                </dd>
              )}
            </dl>
          ) : (
            <p className="text-sm text-[#a89f90]">{INFO_HINT}</p>
          )}
        </div>
      </section>

      {/* 5. tour */}
      <section aria-labelledby="wb-tour">
        <h2 id="wb-tour" className={eyebrow}>5 · Tour</h2>
        {wb.tourStep === null ? (
          <button type="button" onClick={wb.startTour} className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-full border border-[#FF5B14] px-5 py-2.5 text-sm font-bold text-[#FF5B14] transition-colors hover:bg-[#FF5B14] hover:text-[#120f0c]">
            <Play className="size-4" aria-hidden fill="currentColor" />
            Start tour
          </button>
        ) : (
          <div className="mt-2 rounded-xl border border-[#FF5B14] bg-[#FF5B14]/10 p-4">
            <p className="font-mono text-xs font-bold uppercase tracking-wider text-[#FF5B14]">Step {wb.tourStep + 1} of {TOUR.length}</p>
            <p className="mt-1.5 text-[15px]" aria-live="polite">{TOUR[wb.tourStep].caption}</p>
            <div className="mt-3 flex items-center gap-2">
              <button type="button" onClick={wb.tourBack} disabled={wb.tourStep === 0} aria-label="Previous step" className="grid size-9 place-items-center rounded-full border border-[#5a4d3f] disabled:opacity-35">
                <ChevronLeft className="size-4" aria-hidden />
              </button>
              <button type="button" onClick={wb.tourNext} className="inline-flex items-center gap-1.5 rounded-full bg-[#FF5B14] px-4 py-2 text-sm font-bold text-[#120f0c]">
                {wb.tourStep === TOUR.length - 1 ? 'Finish' : 'Next'}
                <ArrowRight className="size-4" aria-hidden />
              </button>
              <button type="button" onClick={wb.endTour} className="ml-auto inline-flex items-center gap-1.5 rounded-full border border-[#5a4d3f] px-3 py-2 text-sm font-medium text-[#d8cfbf] hover:border-[#F5EEDF]">
                <X className="size-4" aria-hidden />
                Skip tour
              </button>
            </div>
          </div>
        )}
      </section>
    </div>
  )
}
